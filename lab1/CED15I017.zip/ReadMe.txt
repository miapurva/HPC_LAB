1. ex1.c contains program for Addition of two matrices using Openmp programming.
2. ex2.c contains program for operation on array elements using Openmp programming
3. Both the graphs are in the same excel/ods file but in different sheets.
   Do check both sheets named as ex1 and ex2 in the same file.
4. Sheet 1- ex1: Write a program to add two matrices with and without using openmp programming and 					calculate the parallel fraction f
5. Sheet 2- ex2: Write a program to perform operations on array elements with and without using 				openmp programming and calculate the parallel fraction f(ex : a[i] = (i+1)*1.0; 
				b[i] = (i+1)*2.0;)