1. mm.cpp contains program for row major matrix multiplication
2. mmcm.cpp contains program for column major matrix multiplication
3. blocking.cpp contains program for blocking matrix multiplication
4. Both the graphs are in the same excel/ods file but in different sheets.
   Do check both sheets named as row major, columnn major and blocking in the same file.
5. Sheet 1- Row major
6. Sheet 2- Column major
7. Sheet 3- Blocking